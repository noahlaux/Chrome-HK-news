document.addEventListener('DOMContentLoaded', function () {

  lib.init({
    'xslPath': 'templates/hknews.xsl',
    'xmlPath': 'http://news.ycombinator.com/rss'
  });

});